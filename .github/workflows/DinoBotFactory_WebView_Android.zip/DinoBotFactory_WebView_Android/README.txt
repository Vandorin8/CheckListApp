DinoBot Factory WebView Android project

The original HTML game is packaged at app/src/main/assets/index.html.
The app launches it locally in a fullscreen Android WebView and supports JavaScript and localStorage/DOM storage.

EASIEST APK BUILD (no Android Studio):
1. Create a new GitHub repository.
2. Upload the CONTENTS of this ZIP to the repository root.
3. Open the repository's Actions tab.
4. Open "Build DinoBot Factory APK" and choose Run workflow.
5. When the build finishes, download the DinoBotFactory-APK artifact.
6. Unzip it; app-debug.apk is the installable APK.

The debug APK is automatically signed with the Android debug key and can be installed directly on an Android phone after allowing installs from the app used to open it.
